package calculator;

import java.util.ArrayList;
import java.util.List;

public abstract class Operation {
    public final String superPriorityOperators = "()";
    public final String priorityOperators = "*/";
    public final String operators = "+-";
    public final String delimiters = " " + operators + priorityOperators;
    public final String superPuperOperators = delimiters + superPriorityOperators;

    public String multiplication(String firstTerm, String secondTerm) {
        return Integer.toString(Integer.parseInt(firstTerm) * Integer.parseInt(secondTerm));
    }

    public String division(String firstTerm, String secondTerm) {
        return Integer.toString(Integer.parseInt(firstTerm) / Integer.parseInt(secondTerm));
    }

    public String addition(String firstTerm, String secondTerm) {
        return Integer.toString(Integer.parseInt(firstTerm) + Integer.parseInt(secondTerm));
    }

    public String subtraction(String firstTerm, String secondTerm) {
        return Integer.toString(Integer.parseInt(firstTerm) - Integer.parseInt(secondTerm));
    }
}