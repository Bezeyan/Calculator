package calculator;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class SplitBrackets extends Operation {
    List<String> dataList = new ArrayList<>();
    String element = "";
    String output = "";

    public void splitBrackets(String dataExpresion) {
        StringTokenizer tokenizer = new StringTokenizer(dataExpresion, superPriorityOperators, true);

        element = tokenizer.nextToken();
        if (!element.equals(dataExpresion)) {
            dataList.add(element);

            while (!element.equals(")")) {
                element = tokenizer.nextToken();
                dataList.add(element);
            }
            dataList.remove(dataList.size() - 1);
            dataList.set(dataList.size() - 1, new SplitLine().split(dataList.get(dataList.size() - 1)));
            dataList.remove(dataList.size() - 2);
            while (tokenizer.hasMoreTokens()) {
                element = tokenizer.nextToken();
                dataList.add(element);
            }
            for (String s : dataList) {
                output += s;
            }
            dataList.clear();
            dataExpresion = output;
            output = "";
            splitBrackets(dataExpresion);
            return;
        }
        System.out.println(new SplitLine().split(dataExpresion));
    }
}