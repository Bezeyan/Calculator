package calculator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Calculator {
    public static void main(String[] args) throws IOException {
        String dataExpresion = new BufferedReader(new FileReader("D:/456.txt")).readLine();
        try {
            System.out.println(Integer.parseInt(new SplitOperations().splitOperations(dataExpresion)));
            //запуск программы
        } catch (NumberFormatException e) {
            System.out.println("Pshel von maloletka, obrabotano");
        }
    }
}
