package calculator;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class SplitOperations extends Operation {
    List<String> dataList = new ArrayList<>();

    public String splitOperations(String dataExpresion) {
        StringTokenizer tokenizer = new StringTokenizer(dataExpresion, superPuperOperators, true);
        while (tokenizer.hasMoreTokens()) {
            dataList.add(tokenizer.nextToken());
        }
        for (int i = 0; i < dataList.size(); i++) {
            if (dataList.get(i).equals("sqrt")) {
                String str = Integer.toString((int) Math.sqrt(
                        Double.parseDouble((new SplitBrackets2().splitBrackets(dataList.get(i + 2))))));
                dataList.remove(i + 1);
                dataList.remove(i + 2);
                dataList.remove(i);
                dataList.set(i, str);
            }
        }
        String output = "";
        for (String s : dataList) {
            output += s;
        }
        return new SplitBrackets2().splitBrackets(output);
    }
}
